# Weather forecast
Simple weather forecast website built with html, css and vanilla js.

## Flow
1. User enters the name of a city into the searchfield and presses search.
2. Fetches coordinates based on location name.
3. Fetches forecast based on coordinates.
4. Structures and displays forecast for the coming week.

## APIs
Uses two APIs:
* [Nominatim](https://nominatim.org/) for fetching coordinates from location name
* [Yr LocationForecast](https://api.met.no/weatherapi/locationforecast/2.0/documentation) for fetching forecast based on coordinates
* [Yr Weathericon](https://api.met.no/weatherapi/weathericon/2.0/documentation) for pre-fetching icons, downloaded and served locally

## Structure
* images -> weathericons
* scripts -> all js
* styles -> all css
* index.html -> markup

## Shortcomings
Nominatim API responds with an array with locations based on relevance. I use the first indexed (highest relevance, most likely target) as my search. This means the user won't have the possibility to choose between different hits, if the first one is wrong. 

## How to use
1. Open index.html in a browser. (Tested and developed in Chrome)