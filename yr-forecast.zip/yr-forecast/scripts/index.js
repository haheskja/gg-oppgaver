// Request settings
const geoAPI = 'https://nominatim.openstreetmap.org/search?format=json&city=$cityName'
const yrAPI = 'https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=$lat&lon=$lon'
const settings = {
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    }
};

// HTML elements
const searchForm = document.getElementById("search-form");
const forecastList = document.getElementById("forecast-list");
const displayCityName = document.getElementById("display-city-name");

/**
 * Handles weather search
 * @param {object} event Button even
 */
const handleSearch = (event) => {
    let cityName = document.getElementById("city-location");
    // Use cityName to find coordinates
    handleGeoSearch(cityName.value)
        .then(jsonResponse => {
            // Use coordinates to find weather data
            const data = handleCoordinates(jsonResponse)
            displayCityName.innerHTML = `${data.display_name}`
            handleYrSearch(data.lat, data.lon)
                .then(jsonResponse => {
                    handleYrData(jsonResponse)
                })
                .catch(error => alert(`Could not fetch weather data from Yr`))
        })
        .catch(error => alert(`Could not fetch geodata`))

    event.preventDefault();
}

/**
 * Performs geosearch based on cityname.
 * For simplicity's sake choose the first result. Means only the most well-known location with the same name can be displayed.
 * @param {string} cityName Name of city
 */
const handleGeoSearch = (cityName) =>
    fetch(geoAPI.replace("$cityName", cityName), settings)
        .then(response => response.json())

/**
 * Performs Yr search
 * @param {string} lat Latitude coordinate
 * @param {string} lon Longitude coordinate
 */
const handleYrSearch = (lat, lon) => 
    fetch(yrAPI.replace("$lat", lat).replace("$lon", lon), settings)
        .then(response => response.json())

/**
 * Handles and verifies coordinate data
 * @param {object} json geoSearch data response
 */
const handleCoordinates = (json) => {
    if(!json) throw new Error('Error processing json')
    if(json.length === 0) throw new Error('No coordinates found')
    return json[0]
}

/**
 * Returns correct timelabels based on index and length of timeseries
 * All four time intervals will be available for future days,
 * the current day will only have time intervals not reached yet.
 * @param {int} index Index to return
 * @param {int} length Length of mapped timeseries
 */
const timeMapper = (index, length) => {
    const allTimes = ["00-06", "06-12", "12-18", "18-24"]
    const times = [...allTimes]
    for(let i = length; i < allTimes.length; i++){
        times.shift()
    }
    return times[index]
}

/**
 * Returns list item based on weather data.
 * @param {object} data Timeseries data
 * @param {*} dateOfWeek Date in readable format
 */
const createLi = (data, dateOfWeek) => 
    document.createRange().createContextualFragment(`
        <li class="listItem listItem-${data.timeseries.length}">
            <div class="itemDay">
                <p>${dateOfWeek}</p>
            </div>
            <div class="itemData">
                ${data.timeseries.map((item, index) => (`
                    <div class="itemRow">
                        <div><strong>${timeMapper(index, data.timeseries.length)}</strong></div>
                        <div>${item.data.instant.details.air_temperature}&deg;</div>
                        <div>
                            <img src="./images/${item.data.next_6_hours.summary.symbol_code}.png" 
                                alt ="forecastSymbol" 
                                class="forecastSymbol"
                            />
                        </div>
                        <div>${item.data.next_6_hours.details.precipitation_amount} mm</div>
                    </div>
                `)).join('')}
            </div>
        </li>`
    )


/**
 * Handles Yr data and appends items to list
 * @param {object} json Yr return data
 */
const handleYrData = (json) => {
    try{
        // Reset ul html
        forecastList.innerHTML = ''

        // Find timeseries
        const timeseries = json.properties.timeseries

        // Group timeseries by date
        const dates = groupTimes(timeseries)
        
        // Iterate through the found dates
        for(let i = 0; i < dates.length; i++){
            const object = dates[i]

            // Format date
            const displayOptions = { weekday: 'long', month: 'short', day: 'numeric' };
            const dateOfWeek = object.date.toLocaleDateString('en-GB', displayOptions)

            // Create li and append to ul
            const li = createLi(object, dateOfWeek)
            forecastList.append(li);
        }
    } catch(error){
        console.error(error)
    }
}

/**
 * Groups timeseries by date.
 * Only groups the times at 0, 6, 12, 18 for use with 6 hour intervals.
 * @param {object} timeseries Yr timeseries
 */
const groupTimes = (timeseries) => {
    // Array mapping each fetched timeseries to a date
    const dates = []

    // The times we care about
    let onlyTimes = [0, 6, 12, 18]

    // The times we care about mapped to include timezone
    const timeZoneOffset = new Date().getTimezoneOffset() / 60
    onlyTimes = onlyTimes.map(item => item - timeZoneOffset)

    // Iterate through all timeseries
    for(let i = 0; i < timeseries.length; i++){
        const object = timeseries[i]
        const date = new Date(object.time)

        let found = false
        let id = null

        // Iterate through all saved dates and compare the current date (without hours)
        // If found, temporarily store the id
        for(let j = 0; j < dates.length; j++){
            const savedDate = dates[j].date.toDateString()
            const compareDate = date.toDateString()

            if(savedDate === compareDate) {
                found = true
                id = j
            }
        }

        // If the current date is not found, add a new entry with the date, and an empty array for timeseries
        if(!found) {
            const length = dates.push({
                date: new Date(date.getFullYear(), date.getMonth(), date.getDate()),
                timeseries: []
            })

            id = length - 1
        }
        
        // For this implementation we only care about 6 hour intervals, so only store those
        if(onlyTimes.includes(date.getHours())){
            dates[id].timeseries.push(object)
        }
    }

    // Pop the last date, as we won't have enough data on it
    dates.pop()
    return dates
}

searchForm.addEventListener("submit", handleSearch);

