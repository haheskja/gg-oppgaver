// Initialize environment variables as early as possible
require('dotenv').config()

// Dependencies 
const express = require('express')
const session = require('express-session')
const path = require('path');
const { server } = require('./server/config')
const router = require('./server/router')
const passport = require('./server/providers/passport')

// Initialize app
const app = express()

// Serve the static files
app.use(express.static(path.join(__dirname, '/build')));

// Initialize middleware and routes
app.use(session({ secret: "something" }));
app.use(passport.initialize());
app.use(passport.session());
app.use(router)

// Serve index.html as fallback
app.get('*', (req, res) =>{
    res.sendFile(path.join(__dirname+'/build/index.html'));
});

// Run app
app.listen(server.port, () => {
  console.log(`Listening at ${server.url}:${server.port}`)
})