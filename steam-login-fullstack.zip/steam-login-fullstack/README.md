# Fullstack app with Steam login

* Bootstrapped with create-react-app
* Added API using Express
* Handled login using passport.js

## Frontend
Simple frontend using React.

1. Allows a user to log in using Steam OpenID
2. See their profile name and avatar
3. Log out again.

Since there was not too much client-side code, I've chosen to not split it up too much, and instead kept most code in `App.js`. Also not installed any routing (like for instance with `react-router`) for the same reason. A more elaborate frontend could often be split up into `Pages`, `Components`, etc. 

### Folder structure
* src -> client/frontend code

## Backend
Backend using Express. Runs the main application.

* Servers the static frontend build files
* Exposes an API for logging in using Steam OpenID
* API for fetching user profile

### Folder structure
* Routes -> all API routes
* Controllers -> controllers for the routes
* Providers -> internal providers such as passport.js
* Services -> external services such as Steam
* config.js -> mappes the environment variables to an object
* router.js -> collects the routes and exposes a router
* app.js -> main entry point for app
  
## How to run
1. Populate `STEAM_API_KEY` in .env with a Steam API key (for fetching profile data)
2. Install dependencies with `yarn`
3. Run app with `yarn start` (build files are included)
4. Website will be available at `SERVER_URL`:`SERVER_PORT` (default is http://localhost:3001)