const express = require('express')
const router = express.Router()
const passport = require('../providers/passport')
const { authController } = require('../controllers')

/**
 * Redirects to Steam login, on success user is sent to:
 * /auth/openid/return
 */
router.get('/openid', passport.authenticate('steam'));

/**
 * Steam redirects to this url after authentication
 */
router.get('/openid/return',
  passport.authenticate('steam', {failureRedirect: '/login' }),
  authController.loginRedirect);

/**
 * Uses passport to terminate the session
 */
router.get('/logout', authController.logout)

module.exports = router