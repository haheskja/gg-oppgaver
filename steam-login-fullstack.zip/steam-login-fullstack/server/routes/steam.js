const express = require('express')
const router = express.Router()
const { steamController } = require('../controllers')

/**
 * Fetche the Steam user's profile data
 */
router.get('/user', steamController.fetchUser)

module.exports = router