const steamRouter = require('./steam')
const authRouter = require('./auth')

module.exports = {
    steamRouter,
    authRouter,
}