const passport = require('passport')
const SteamStrategy = require('passport-steam').Strategy;

const { server } = require('../config')

/**
 * Define a new SteamStrategy and append it to the passport object
 */
passport.use(new SteamStrategy({
    returnURL: `${server.url}:${server.port}/auth/openid/return`,
    realm: `${server.url}:${server.port}/`,
    // Could have put this to true to automatically fetch the profile object. Decided against it for the sake of the coding task, to not rely too heavily on 3rd party packages.
    profile: false,
  },
  function(identifier, profile, done){
    const user = {
        // Use regex to extract the 64bit Steam ID from the identifier URL
        id: identifier.match(/\d+$/)[0],
    };

    return done(null, user);
  }
));

/**
 * Serializes the userId into express session
 */
passport.serializeUser((user, done) => {
    done(null, user.id);
});

/**
 * Deserializes the user from userId (steamId) to an object
 */
passport.deserializeUser((id, done) => {
    // Since we're not storing anything persistently, return a user object with the id
    const user = {
        id: id
    }

    done(null, user);
});

module.exports = passport