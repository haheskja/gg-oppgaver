const config = {
    server: {
        port: process.env.SERVER_PORT,
        url: process.env.SERVER_URL,
        steamApiKey: process.env.STEAM_API_KEY,
        ISteamUserUrl: `https://api.steampowered.com/ISteamUser` 
    }
}

module.exports = config