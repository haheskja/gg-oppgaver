const express = require('express')
const routes = require('./routes')

const router = express.Router()

router.use('/auth', routes.authRouter)
router.use('/steam', routes.steamRouter)

module.exports = router