const authController = require('./auth')
const steamController = require('./steam')

module.exports = {
    authController,
    steamController,
}