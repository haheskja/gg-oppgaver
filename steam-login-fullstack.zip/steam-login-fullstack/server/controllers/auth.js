/**
 * Redirects the user after login
 * @param {object} req Express request object
 * @param {object} res Express response object
 */
const loginRedirect = (req, res) => {
    res.redirect('/')
}

/**
 * Terminates the user session
 * @param {object} req Express request object
 * @param {object} res Express response object
 */
const logout = (req, res) => {
    req.logout()
    res.redirect('/')
}

module.exports = {
    loginRedirect,
    logout,
}