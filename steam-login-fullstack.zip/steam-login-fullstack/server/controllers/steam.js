const steamService = require('../services/steam')

/**
 * Controller responsible for handling fetching of user
 * @param {object} req Express request object
 * @param {object} res Express response object
 * @returns {boolean} false if not logged in
 * @returns {object} with profile information if logged in
 */
const fetchUser = async (req, res) => {
    try{
        // If no user is logged in, return false
        if(req.user === undefined){
            res.send(false)
        }
        // If user logged in, fetch the their profile
        else {
            const response = await steamService.fetchSteamUser(req.user.id)

            // Check for response code
            if(response.status === 200){

                // Should only expect one profile, if there is more something is wrong
                if(response.data.response.players.length === 1){

                    // Return the profile data
                    res.send(response.data.response.players[0])
                }
                else res.status(400).send({error: `Expected only 1 result, got ${response.data.response.players.length}.`})
            }
        }
    } catch(error){
        console.error(error)
        res.status(500).send({error: 'Internal server error.'})
    }
}

module.exports = {
    fetchUser,
}