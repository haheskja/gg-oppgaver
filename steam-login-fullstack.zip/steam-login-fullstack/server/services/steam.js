const axios = require('axios')
const { server } = require('../config')

/**
 * Fetches profile information from one Steam user
 * @param {string} steamId 64bit Steam ID
 */
const fetchSteamUser = steamId => 
    axios({
        method: 'GET',
        url: `${server.ISteamUserUrl}/GetPlayerSummaries/v0002/`, 
        params: {
            steamids: steamId,
            key: server.steamApiKey
        }
    })

module.exports = {
    fetchSteamUser,
}