import React, { useState, useEffect } from 'react'
import { isLoggedIn } from './api'

const App = () => {
  // State management using hooks
  const [ user, setUser ] = useState({})
  const [ loggedIn, setLoggedIn ] = useState(false)
  const [ isLoading, setIsLoading ] = useState(true)

  // Runs once when the page is loaded
  useEffect(() => {
    const initialize = async () => {
      const response = await isLoggedIn()

      // If we get back data from the request, use it to populate the state
      if(response.data){
        setLoggedIn(true)
        setUser(response.data)
      }

      setIsLoading(false)
    }

    initialize()
  }, [])

  const createContent = () => {
    // If we are still loading
    if(isLoading) return <p>Loading...</p>

    // If the user is logged in
    if(loggedIn) return (
      <div className="Login">
        <div className="Row">
          <p>You are logged in as <strong>{user.personaname}</strong></p>
          <a href="/auth/logout" className="LogoutText">&gt; Log out</a>
        </div>
        <div className="Row">
          <img src={`${user.avatarmedium}`} alt="SteamAvatar" />
        </div>
      </div>
    )
    // If the user needs to log in
    else return (
      <div className="Login">
        <div className="Row">
          <p>Please log in with Steam to continue -&gt;</p>
        </div>
        <div className="Row">
          <a href="/auth/openid">
            <img src="https://community.akamai.steamstatic.com/public/images/signinthroughsteam/sits_02.png" alt="SteamLoginImage" />
          </a>
        </div>
      </div>
  )}

  // Main return 
  return (
    <div className="Container">
      <div className="Content">
        {createContent()}
      </div>
    </div>
  )
}

export default App;
