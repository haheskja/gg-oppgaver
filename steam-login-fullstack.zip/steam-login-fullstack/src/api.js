import axios from 'axios'

/**
 * An user object if logged in, false if not
 */
export const isLoggedIn = () => axios.get('/steam/user')